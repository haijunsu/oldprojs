/*
 * @(#)RegisterServiceJdbcImpl.java  2005-3-4
 * Copyright (c) 2005. All rights reserved. 
 * 
 * $Header$
 * $Log$
 */
package application.service.impl;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import application.dao.AccompanyPersonDao;
import application.dao.CoauthorDao;
import application.dao.PaperDao;
import application.dao.ParticipantDao;
import application.dao.RegistrationFeeDao;
import application.dao.RelationBetweenParticipantAndPaperDao;
import application.dao.UserAccountDao;
import application.entities.TaccompanyPerson;
import application.entities.Tcoauthor;
import application.entities.Tpaper;
import application.entities.Tparticipant;
import application.entities.TregistrationFee;
import application.entities.TrelationBetweenParticipantAndPaper;
import application.entities.TuserAccount;
import application.exception.BusinessServiceException;
import application.service.RegisterService;
import application.util.EntitiesTransUtil;
import application.viewdata.AccompanyPersonView;
import application.viewdata.RegistrationView;
import application.viewdata.SmallPaperView;
import framework.exception.DaoException;
import framework.service.impl.JdbcServiceImpl;

/**
 * <p>
 * <b>Description </b>
 * </p>
 * <p>
 * </p>
 * 
 * $Revision$
 * 
 * @author su_haijun <a href=mailto:su_hj@126.com>su_hj@126.com </a>
 */
public class RegisterServiceJdbcImpl extends JdbcServiceImpl implements
        RegisterService {
    /**
     * Logger for this class
     */
    private static final Log logger = LogFactory
            .getLog(RegisterServiceJdbcImpl.class);

    private ParticipantDao m_participantDao;

    private CoauthorDao m_coauthorDao;

    private UserAccountDao m_userAccountDao;

    private PaperDao m_paperDao;

    private AccompanyPersonDao m_accompanyPersonDao;

    private RelationBetweenParticipantAndPaperDao m_relationBetweenParticipantAndPaperDao;
    
    private RegistrationFeeDao m_registrationFeeDao;

    public RegistrationFeeDao getRegistrationFeeDao() {
        return this.m_registrationFeeDao;
    }
    public void setRegistrationFeeDao(RegistrationFeeDao registrationFeeDao) {
        this.m_registrationFeeDao = registrationFeeDao;
    }
    public RelationBetweenParticipantAndPaperDao getRelationBetweenParticipantAndPaperDao() {
        return this.m_relationBetweenParticipantAndPaperDao;
    }

    public void setRelationBetweenParticipantAndPaperDao(
            RelationBetweenParticipantAndPaperDao relationBetweenParticipantAndPaperDao) {
        this.m_relationBetweenParticipantAndPaperDao = relationBetweenParticipantAndPaperDao;
    }

    public AccompanyPersonDao getAccompanyPersonDao() {
        return this.m_accompanyPersonDao;
    }

    public void setAccompanyPersonDao(AccompanyPersonDao accompanyPersonDao) {
        this.m_accompanyPersonDao = accompanyPersonDao;
    }

    public CoauthorDao getCoauthorDao() {
        return this.m_coauthorDao;
    }

    public void setCoauthorDao(CoauthorDao coauthorDao) {
        this.m_coauthorDao = coauthorDao;
    }

    public PaperDao getPaperDao() {
        return this.m_paperDao;
    }

    public void setPaperDao(PaperDao paperDao) {
        this.m_paperDao = paperDao;
    }

    public ParticipantDao getParticipantDao() {
        return this.m_participantDao;
    }

    public void setParticipantDao(ParticipantDao participantDao) {
        this.m_participantDao = participantDao;
    }

    public UserAccountDao getUserAccountDao() {
        return this.m_userAccountDao;
    }

    public void setUserAccountDao(UserAccountDao userAccountDao) {
        this.m_userAccountDao = userAccountDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#loadRegistrationByParticipantNo(java.lang.String)
     */
    public RegistrationView loadRegistrationByParticipantNo(String participantNo)
            throws BusinessServiceException {
        if (logger.isDebugEnabled()) {
            logger.debug("loadRegistrationByParticipantNo(String) - start");
        }

        try {
            RegistrationView _registrationView = new RegistrationView();
            Tparticipant _participant = getParticipantDao()
                    .findByParticipantNo(participantNo);
            _registrationView.setParticipant(_participant);
            TaccompanyPerson[] _arrayAccompanyPerson = getAccompanyPersonDao()
                    .findByParticipantNo(participantNo);
            AccompanyPersonView[] _arrayAccompanyPersonView = new AccompanyPersonView[_arrayAccompanyPerson.length];
            for (int i = 0; i < _arrayAccompanyPersonView.length; i++) {
                _arrayAccompanyPersonView[i] = new AccompanyPersonView();
                BeanUtils.copyProperties(_arrayAccompanyPersonView[i], _arrayAccompanyPerson[i]);
            }
            _registrationView.setAccompanyPerson(_arrayAccompanyPersonView);
            Tpaper[] _arrayPaper = getPaperDao().findByPartiNo(participantNo);
            SmallPaperView[] _arraySmallPaperView = new SmallPaperView[_arrayPaper.length];
            for (int i = 0; i < _arraySmallPaperView.length; i++) {
                _arraySmallPaperView[i] = new SmallPaperView();
                BeanUtils.copyProperties(_arraySmallPaperView[i],
                        _arrayPaper[i]);
            }
            _registrationView.setPapers(_arraySmallPaperView);

            if (logger.isDebugEnabled()) {
                logger.debug("loadRegistrationByParticipantNo(String) - end");
            }
            return _registrationView;
        } catch (DaoException e) {
            logger
                    .error(
                            "loadRegistrationByParticipantNo(String) - DaoException",
                            e);

            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            logger.error("loadRegistrationByParticipantNo(String) - Exception",
                    e);

            throw new BusinessServiceException(97, e.getMessage());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#loadRegistrationByUserID(java.lang.Integer)
     */
    public RegistrationView loadRegistrationByUserID(Integer userid)
            throws BusinessServiceException {
        if (logger.isDebugEnabled()) {
            logger.debug("loadRegistrationByUserID(Integer) - start");
        }

        try {
            RegistrationView _registrationView = new RegistrationView();
            TuserAccount _userAccount = getUserAccountDao()
                    .findByUserid(userid);
            Tparticipant _participant = EntitiesTransUtil
                    .userAccountTransToParticipant(_userAccount);
            _registrationView.setParticipant(_participant);
            TaccompanyPerson[] _arrayAccompanyPerson = new TaccompanyPerson[0];
            AccompanyPersonView[] _arrayAccompanyPersonView = new AccompanyPersonView[_arrayAccompanyPerson.length];
            for (int i = 0; i < _arrayAccompanyPersonView.length; i++) {
                _arrayAccompanyPersonView[i] = new AccompanyPersonView();
                BeanUtils.copyProperties(_arrayAccompanyPersonView[i], _arrayAccompanyPerson[i]);
            }
            _registrationView.setAccompanyPerson(_arrayAccompanyPersonView);
            Tpaper[] _arrayPaper = getPaperDao().findAllPapersByUserid(userid);
            SmallPaperView[] _arraySmallPaperView = new SmallPaperView[_arrayPaper.length];
            for (int i = 0; i < _arraySmallPaperView.length; i++) {
                _arraySmallPaperView[i] = new SmallPaperView();
                BeanUtils.copyProperties(_arraySmallPaperView[i],
                        _arrayPaper[i]);
            }
            _registrationView.setPapers(_arraySmallPaperView);

            if (logger.isDebugEnabled()) {
                logger.debug("loadRegistrationByUserID(String) - end");
            }
            return _registrationView;
        } catch (DaoException e) {
            logger
                    .error(
                            "loadRegistrationByUserID(String) - DaoException",
                            e);

            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            logger.error("loadRegistrationByUserID(String) - Exception",
                    e);

            throw new BusinessServiceException(97, e.getMessage());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#loadRegistrationByPaperNumberAndEmail(java.lang.String,
     *      java.lang.String)
     */
    public RegistrationView loadRegistrationByPaperNumberAndEmail(
            String paperNumber, String email) throws BusinessServiceException {
        if (logger.isDebugEnabled()) {
            logger.debug("loadRegistrationByUserID(Integer) - start");
        }

        try {
            RegistrationView _registrationView = new RegistrationView();
            Tcoauthor _coauthor = getCoauthorDao().findCoauthor(paperNumber, email);
            Tparticipant _participant = EntitiesTransUtil
                    .coauthorTransToParticipant(_coauthor);
            _registrationView.setParticipant(_participant);
            TaccompanyPerson[] _arrayAccompanyPerson = new TaccompanyPerson[0];
            AccompanyPersonView[] _arrayAccompanyPersonView = new AccompanyPersonView[_arrayAccompanyPerson.length];
            for (int i = 0; i < _arrayAccompanyPersonView.length; i++) {
                _arrayAccompanyPersonView[i] = new AccompanyPersonView();
                BeanUtils.copyProperties(_arrayAccompanyPersonView[i], _arrayAccompanyPerson[i]);
            }
            _registrationView.setAccompanyPerson(_arrayAccompanyPersonView);
            Tpaper[] _arrayPaper = getPaperDao().findAllPapersByEmail(email);
            SmallPaperView[] _arraySmallPaperView = new SmallPaperView[_arrayPaper.length];
            for (int i = 0; i < _arraySmallPaperView.length; i++) {
                _arraySmallPaperView[i] = new SmallPaperView();
                BeanUtils.copyProperties(_arraySmallPaperView[i],
                        _arrayPaper[i]);
            }
            _registrationView.setPapers(_arraySmallPaperView);

            if (logger.isDebugEnabled()) {
                logger.debug("loadRegistrationByUserID(String) - end");
            }
            return _registrationView;
        } catch (DaoException e) {
            logger
                    .error(
                            "loadRegistrationByUserID(String) - DaoException",
                            e);

            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            logger.error("loadRegistrationByUserID(String) - Exception",
                    e);

            throw new BusinessServiceException(97, e.getMessage());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#updateParticipant(application.entities.Tparticipant)
     */
    public void updateParticipant(Tparticipant participant)
            throws BusinessServiceException {
        try {
            getParticipantDao().update(participant);
        } catch (DaoException e) {
            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            throw new BusinessServiceException(97, e.getMessage());
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#createParticipant(application.entities.Tparticipant)
     */
    public void createParticipant(Tparticipant participant)
            throws BusinessServiceException {
        try {
            getParticipantDao().create(participant);
            Tcoauthor[] _arrayCoauthor = getCoauthorDao().findByEmail(participant.getChvPartiEmail(), true);
            TuserAccount[] _arrayUserAccount = getUserAccountDao().findByUserAccount(participant.getChvPartiEmail());
            Tpaper[][] _arrayPaper = new Tpaper[_arrayUserAccount.length][0];
            int _nPaperCount = _arrayCoauthor.length;
            for (int i = 0; i < _arrayPaper.length; i++) {
                _arrayPaper[i] = getPaperDao().findAllPapersByUserid(_arrayUserAccount[i].getIntUserID());
                _nPaperCount += _arrayPaper[i].length;
            }
            
            TrelationBetweenParticipantAndPaper[] _relationBetweenParticipantAndPapers = new TrelationBetweenParticipantAndPaper[_nPaperCount];
            int _nIndex = 0;
            for (int i = 0; i < _arrayCoauthor.length; i++) {
                _relationBetweenParticipantAndPapers[_nIndex] = new TrelationBetweenParticipantAndPaper();
                _relationBetweenParticipantAndPapers[_nIndex].setChrPartiNo(participant.getChrPartiNo());
                _relationBetweenParticipantAndPapers[_nIndex].setChvPaperNumber(_arrayCoauthor[i].getChvPaperNumber());
                _relationBetweenParticipantAndPapers[_nIndex].setInyAuthorRank(_arrayCoauthor[i].getInyAuthorRank());
                _nIndex ++;
            }
            for (int i = 0; i < _arrayPaper.length; i++) {
                for (int j = 0; j < _arrayPaper[i].length; j++) {
                    _relationBetweenParticipantAndPapers[_nIndex] = new TrelationBetweenParticipantAndPaper();
                    _relationBetweenParticipantAndPapers[_nIndex].setChrPartiNo(participant.getChrPartiNo());
                    _relationBetweenParticipantAndPapers[_nIndex].setChvPaperNumber(_arrayPaper[i][j].getChvPaperNumber());
                    _relationBetweenParticipantAndPapers[_nIndex].setInyAuthorRank(_arrayPaper[i][j].getInyAuthorRank());
                    _relationBetweenParticipantAndPapers[_nIndex].setIntUserID(_arrayPaper[i][j].getIntUserID());
                    _nIndex ++;
                }
            }
            _relationBetweenParticipantAndPapers = EntitiesTransUtil.removeDuplicateArray(_relationBetweenParticipantAndPapers);
            for (int i = 0; i < _relationBetweenParticipantAndPapers.length; i++) {
                getRelationBetweenParticipantAndPaperDao().create(_relationBetweenParticipantAndPapers[i]);
            }
            TregistrationFee _tregistrationFee = new TregistrationFee();
            _tregistrationFee.setChrPartiNo(participant.getChrPartiNo());
            _tregistrationFee.setChrPaymentMethodNo("1");
            getRegistrationFeeDao().create(_tregistrationFee);
            
        } catch (DaoException e) {
            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            throw new BusinessServiceException(97, e.getMessage());
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see application.service.RegisterService#removeParticipant(application.entities.Tparticipant)
     */
    public void removeParticipant(Tparticipant participant)
            throws BusinessServiceException {
        try {
            getParticipantDao().remove(participant);
        } catch (DaoException e) {
            throw new BusinessServiceException(99, e.getMessage());
        } catch (Exception e) {
            throw new BusinessServiceException(97, e.getMessage());
        }
    }

}