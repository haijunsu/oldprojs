/*
 * @(#)ExecuteSqlHelper.java  2005-3-22
 * Copyright (c) 2005. All rights reserved. 
 * 
 * $Header$
 * $Log$
 */
package application.action.jdbc;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import application.dao.impl.BaseDaoJdbcImpl;
import framework.exception.DaoException;
import framework.util.StringUtil;

/**
 * <p><b>Description</b></p>
 * <p></p>
 * 
 * $Revision$
 * @author su_haijun  <a href=mailto:su_hj@126.com>su_hj@126.com</a>
 */
public class ExecuteSqlHelper extends BaseDaoJdbcImpl {
    
    /**
     * Logger for this class
     */
    private static final Log logger = LogFactory.getLog(ExecuteSqlHelper.class);
    
    public String execute(String strSql) throws DaoException {
        int _nRows = 0;
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("execute(String) - SQL: " + strSql);
            }
        _nRows = getJdbcTemplate().update(strSql);
        } catch (Exception e) {
            logger.error("execute(String) - exception", e);
            return e.getMessage();
         }
        String _string = _nRows + " rows affected.";
        if (_nRows < 2) {
            _string = _nRows + " row affected.";
        }
        return _string;
    }
    
    public Object[][] Query(String strSql) throws DaoException {
        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Query(String) - SQL: " + strSql);
            }
            List _list = getJdbcTemplate().queryForList(strSql);
            if (_list != null && !_list.isEmpty()) {
               return populateResult(_list);
            }
            String[][] _strings = new String[1][1];
            _strings[0][0] = "result is empty.";
            return _strings;
        } catch (Exception e) {
            logger.error("Query(String) - exception", e);
            String[][] _strings = new String[1][1];
            _strings[0][0] = e.getMessage();
            return _strings;
         }

    }
    
    private Object[][] populateResult(List list) {
        Object[][] _results = new Object[list.size() + 1][];
        Object[] _titles = null;
        int _nRow = 0;
        Iterator _iterator = list.iterator();
        while (_iterator.hasNext()) {
	        HashMap _map = (HashMap)_iterator.next();
	        Iterator _iterator2 = _map.keySet().iterator();
	        if (_titles == null) {
	            _titles = _map.keySet().toArray(new Object[0]);
	            _results[_nRow] = _titles;
	            _nRow ++;
	        }
	        int _nCol = 0;
	        Object[] _objects = new Object[_titles.length];
	        while (_iterator2.hasNext()) {
	            _objects[_nCol] = _map.get(_iterator2.next());
	            if (_objects[_nCol] == null) {
	                _objects[_nCol] = "null";
	            }
	            if (_objects[_nCol] instanceof String) {
	                _objects[_nCol] = StringUtil.abbreviate(_objects[_nCol].toString(), 150);
	            }
	            _nCol ++;
	        }
            _results[_nRow] = _objects;
            _nRow ++;
        }
        return _results;
    }
    /* (non-Javadoc)
     * @see application.dao.BaseDao#listEntities(java.lang.String, java.lang.String)
     */
    public Object[] listEntities(String condition, String orderBy) throws DaoException {
        // TODO Auto-generated method stub
        return null;
    }
}
