/*
 * @(#)ExecuteSqlAction.java  2005-3-22
 * Copyright (c) 2005. All rights reserved. 
 * 
 * $Header$
 * $Log$
 */
package application.action.jdbc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import application.action.BaseDispachAction;
import application.dao.MyQuerysDao;
import application.entity.MyQuerys;
import application.helper.BeansLocator;
import framework.exception.CannotFoundRequestParameterException;
import framework.util.StringUtil;
import framework.util.http.RequestUtil;

/**
 * <p>
 * <b>Description </b>
 * </p>
 * <p>
 * </p>
 * 
 * $Revision$
 * 
 * @author su_haijun <a href=mailto:su_hj@126.com>su_hj@126.com </a>
 */
public class ExecuteSqlAction extends BaseDispachAction {
    /**
     * Logger for this class
     */
    private static final Log logger = LogFactory.getLog(ExecuteSqlAction.class);

    public ActionForward runSql(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        ActionForward _forward = mapping.findForward("executePage");
        ActionMessages _messages = new ActionMessages();
        try {
            String _strSqlParam = RequestUtil.getStringParameter(request,
                    "sqls", "");
            if (StringUtil.isBlank(_strSqlParam)) {
                return _forward;
            }
            String[] _strSqls = StringUtil.split(_strSqlParam, ";");
            ExecuteSqlHelper _sqlHelper = (ExecuteSqlHelper) BeansLocator
                    .getBeanResource("sqlDao");
            Object[][] _objects = null;
            int _nloop = _strSqls.length;
            if (_nloop > 1 && StringUtil.isBlank(_strSqls[_nloop - 1])) {
                _nloop--;
            }
            _objects = new Object[_nloop][1];
            request.setAttribute("isSelect", "false");
            if (_nloop > 1) {
                for (int i = 0; i < _nloop; i++) {
                    _objects[i][0] = _sqlHelper.execute(_strSqls[i].trim());
                }
            } else {
                if (_strSqls[0].toLowerCase().trim().startsWith("select")) {
                    request.setAttribute("isSelect", "true");
                    _objects = _sqlHelper.Query(_strSqls[0].trim());
                } else {
                    if (StringUtil.isNotBlank(_strSqls[0])) {
                        _objects = new Object[1][1];
                        _objects[0][0] = _sqlHelper.execute(_strSqls[0].trim());
                    }
                }
            }
            
            request.setAttribute("results", _objects);
        } catch (Exception e) {
            logger
                    .error(
                            "runSql(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - Uncatched Exception!",
                            e);

        }
        return _forward;
    }
    
    public ActionForward query(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        ActionForward _forward = mapping.findForward("resultsPage");
        ActionMessages _messages = new ActionMessages();
        try {
            String _strQueryid = RequestUtil.getRequiredStringParameter(request,
                    "queryid");
            //TODO 根据queryid来进行查询,menu增加从查询表中取菜单，增加查询管理
            MyQuerysDao _querysDao = (MyQuerysDao) BeansLocator.getBeanResource("querysDao");
            MyQuerys _querys = _querysDao.load(new Long(_strQueryid));
            ExecuteSqlHelper _sqlHelper = (ExecuteSqlHelper) BeansLocator
                    .getBeanResource("sqlDao");
            Object[][] _objects = new Object[1][1];
            request.setAttribute("isSelect", "true");
            _objects = _sqlHelper.Query(_querys.getQuerySql().trim());
            
            request.setAttribute("results", _objects);
            request.setAttribute("queryTitle", _querys.getQueryName());
        } catch (CannotFoundRequestParameterException e) {
            logger
                    .error(
                            "query(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)",
                            e);

            _messages
                    .add("jdbcError", new ActionMessage("errors.code.132"));
            saveErrors(request, _messages);
            _forward = mapping.findForward("error");
        } catch (Exception e) {
            logger
                    .error(
                            "query(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - Uncatched Exception!",
                            e);

        }
        return _forward;
    }
}